module.exports.CONNECTION_LIMIT = 10000;
module.exports.HOST = "quora.cmgpt7pa9mg7.us-west-1.rds.amazonaws.com";
module.exports.USER = "quora";
module.exports.PASSWORD = "quora123";
module.exports.DATABASE = "quora";
